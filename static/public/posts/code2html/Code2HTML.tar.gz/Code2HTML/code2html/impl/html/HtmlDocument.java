/*
 * HtmlDocument.java
 * Copyright (c) 2002 Andre Kaplan
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


package code2html.impl.html;

import java.io.IOException;
import java.io.Writer;

import org.gjt.sp.jedit.syntax.SyntaxStyle;

import code2html.generic.* ;

public class HtmlDocument extends GenericDocument {
    
    public HtmlDocument(
            String        viewBgColor,
            String        viewFgColor,
            SyntaxStyle[] syntaxStyles,
            Style     style,
            GenericGutter    gutter,
            String        title,
            String        lineSeparator
    ) {
			super(  viewBgColor   , viewFgColor   , syntaxStyles  , 
				style, gutter, title, lineSeparator ) ;
    }

		@Override
    public void open(Writer out) throws IOException {
        out.write("<html>");
        out.write(this.lineSeparator);
        out.write("<head>");
        out.write(this.lineSeparator);
        out.write("<title>" + this.title + "</title>");
        out.write(this.lineSeparator);
        out.write("</head>");
        out.write(this.lineSeparator);
        out.write("<body bgcolor=\"");
        out.write(this.viewBgColor);
        out.write("\">");
        out.write(this.lineSeparator);
        out.write("<pre>");
        
				out.write("<font color=\"");
        out.write(this.viewFgColor);
        out.write("\">");
    }

		@Override
    public void close(Writer out) throws IOException {
        out.write("</font>");
				out.write("</pre>");
        out.write(this.lineSeparator);
        out.write("</body>");
        out.write(this.lineSeparator);
        out.write("</html>");
        out.write(this.lineSeparator);
    }
}

