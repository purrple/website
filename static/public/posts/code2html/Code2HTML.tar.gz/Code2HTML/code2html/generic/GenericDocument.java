/*
 * GenericDocument.java
 * Copyright (c) 2009 Romain Francois <francoisromain@free.fr>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


package code2html.generic ;

import java.io.IOException;
import java.io.Writer;

import org.gjt.sp.jedit.syntax.SyntaxStyle;
import java.awt.Color ;

public abstract class GenericDocument {
    protected String        viewBgColor;
    protected String        viewFgColor;
		
		protected Color bgColor ;
		protected Color fgColor ;

    protected SyntaxStyle[] syntaxStyles;

    protected Style     style;
    protected GenericGutter    gutter;

    protected String        title;
    protected String        lineSeparator;

		public GenericDocument(){}
		
    public GenericDocument(
            String        viewBgColor,
            String        viewFgColor,
            SyntaxStyle[] syntaxStyles,
            Style  style,
            GenericGutter gutter,
            String        title,
            String        lineSeparator
    ) {
        this.viewBgColor   = viewBgColor;
        this.viewFgColor   = viewFgColor;
				this.bgColor = Color.decode( viewBgColor ) ;
				this.fgColor = Color.decode( viewFgColor ) ;
				
        this.syntaxStyles  = syntaxStyles;
        this.style         = style;
        this.gutter        = gutter;
        this.title         = title;
        this.lineSeparator = lineSeparator;
    }

    public abstract void open(Writer out) throws IOException ;
    
    public abstract void close(Writer out) throws IOException ; 
		
}

