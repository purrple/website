public class HelloJavaWorld {
   
  public String sayHello() {
    String result = new String("Hello Java World!");
    return result;
  }

  public static void main(String[] args) {
  }

} 
