import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class HelloJavaWorld_Test {
	
	@Test
	public void test(){
		HelloJavaWorld greeter = new HelloJavaWorld(); 
		String message = greeter.sayHello(); 
		assertEquals( "Hello Java World!", message ) ;
	}
	
}

