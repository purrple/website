public class HelloJavaWorld {
   
  public String sayHello() {
    String result = new String("Hello Java World!");
    return result;
  }

} 
