package com.trolltech.research.qtjambiawtbridge.generated;

import com.trolltech.qt.*;


@QtJambiGeneratedClass
public class QWidgetHostNative extends com.trolltech.qt.gui.QWidget
{

    static {
        com.trolltech.research.qtjambiawtbridge.generated.QtJambi_LibraryInitializer.init();
    }

    public QWidgetHostNative(java.lang.Object parentWindow){
        super((QPrivateConstructor)null);
        __qt_QWidgetHostNative_java_lang_Object(parentWindow);
    }

    native void __qt_QWidgetHostNative_java_lang_Object(java.lang.Object parentWindow);

    @QtBlockedSlot
    protected void childEvent(com.trolltech.qt.core.QChildEvent e)    {
        com.trolltech.qt.GeneratorUtilities.threadCheck(this);
        if (nativeId() == 0)
            throw new QNoNativeResourcesException("Function call on incomplete object of type: " +getClass().getName());
        __qt_childEvent_QChildEvent(nativeId(), e == null ? 0 : e.nativeId());
    }
    @QtBlockedSlot
    native void __qt_childEvent_QChildEvent(long __this__nativeId, long e);

    @QtBlockedSlot
    public boolean event(com.trolltech.qt.core.QEvent arg__1)    {
        com.trolltech.qt.GeneratorUtilities.threadCheck(this);
        if (nativeId() == 0)
            throw new QNoNativeResourcesException("Function call on incomplete object of type: " +getClass().getName());
        return __qt_event_QEvent(nativeId(), arg__1 == null ? 0 : arg__1.nativeId());
    }
    @QtBlockedSlot
    native boolean __qt_event_QEvent(long __this__nativeId, long arg__1);

    @QtBlockedSlot
    public boolean eventFilter(com.trolltech.qt.core.QObject o, com.trolltech.qt.core.QEvent e)    {
        com.trolltech.qt.GeneratorUtilities.threadCheck(this);
        if (nativeId() == 0)
            throw new QNoNativeResourcesException("Function call on incomplete object of type: " +getClass().getName());
        return __qt_eventFilter_QObject_QEvent(nativeId(), o == null ? 0 : o.nativeId(), e == null ? 0 : e.nativeId());
    }
    @QtBlockedSlot
    native boolean __qt_eventFilter_QObject_QEvent(long __this__nativeId, long o, long e);

    @QtBlockedSlot
    protected void focusInEvent(com.trolltech.qt.gui.QFocusEvent e)    {
        com.trolltech.qt.GeneratorUtilities.threadCheck(this);
        if (nativeId() == 0)
            throw new QNoNativeResourcesException("Function call on incomplete object of type: " +getClass().getName());
        __qt_focusInEvent_QFocusEvent(nativeId(), e == null ? 0 : e.nativeId());
    }
    @QtBlockedSlot
    native void __qt_focusInEvent_QFocusEvent(long __this__nativeId, long e);

    @QtBlockedSlot
    protected void resizeEvent(com.trolltech.qt.gui.QResizeEvent arg__1)    {
        com.trolltech.qt.GeneratorUtilities.threadCheck(this);
        if (nativeId() == 0)
            throw new QNoNativeResourcesException("Function call on incomplete object of type: " +getClass().getName());
        __qt_resizeEvent_QResizeEvent(nativeId(), arg__1 == null ? 0 : arg__1.nativeId());
    }
    @QtBlockedSlot
    native void __qt_resizeEvent_QResizeEvent(long __this__nativeId, long arg__1);

    public static native QWidgetHostNative fromNativePointer(QNativePointer nativePointer);

    private static native long originalMetaObject();

    protected QWidgetHostNative(QPrivateConstructor p) { super(p); } 
}
