package com.trolltech.research.qtjambiawtbridge.generated;

class QtJambi_LibraryInitializer
{
    static {

        com.trolltech.qt.Utilities.Configuration oldConfiguration = com.trolltech.qt.Utilities.configuration;
        com.trolltech.qt.Utilities.configuration = com.trolltech.qt.Utilities.Configuration.Release;
        com.trolltech.qt.Utilities.loadLibrary("jawt");
        com.trolltech.qt.Utilities.configuration = oldConfiguration;
            com.trolltech.qt.Utilities.loadJambiLibrary("com_trolltech_research_qtjambiawtbridge_generated");
        __qt_initLibrary();
    }
    private native static void __qt_initLibrary();
    static void init() { };
}

