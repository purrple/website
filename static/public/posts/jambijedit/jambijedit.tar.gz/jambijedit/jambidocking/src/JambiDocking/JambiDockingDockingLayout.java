package JambiDocking;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.gjt.sp.jedit.gui.DockableWindowManager.DockingLayout;

public class JambiDockingDockingLayout extends DockingLayout {

	public JambiDockingDockingLayout() {}
	
	@Override
	public boolean loadLayout(String baseName, int viewIndex) {
		return true;
	}

	@Override
	public boolean saveLayout(String baseName, int viewIndex) {
		return true;
	}

	@Override
	public String getName() {
		return "JambiDockingPlugin";
	}

}
