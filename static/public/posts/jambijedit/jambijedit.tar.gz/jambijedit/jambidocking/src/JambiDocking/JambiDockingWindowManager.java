package JambiDocking;

import java.awt.Component ;
import java.awt.BorderLayout;
import javax.swing.* ;

import org.gjt.sp.jedit.jEdit ;
import org.gjt.sp.jedit.View ;
import org.gjt.sp.jedit.View.ViewConfig;
import org.gjt.sp.jedit.gui.DockableWindowFactory;
import org.gjt.sp.jedit.gui.DockableWindowManager ;
import org.gjt.sp.jedit.gui.DefaultFocusComponent ;
import java.util.HashMap ;

import com.trolltech.qt.gui.*;
import com.trolltech.research.qtjambiawtbridge.QComponentHost;


public class JambiDockingWindowManager extends DockableWindowManager {

	private HashMap<String,QDockWidget> _widgets ;
	private HashMap<String,Component> _components ;
	
	public JambiDockingDockingLayout _layout ;
		
	public JambiDockingWindowManager( 
			View view, 
			DockableWindowFactory instance,
			ViewConfig config){
		
	  super(view, instance, config);
		setLayout( new BorderLayout() ) ;
		_layout  = new JambiDockingDockingLayout();
		_widgets = new HashMap<String,QDockWidget>( ) ;
		_components = new HashMap<String,Component>( ) ;
	}

	@Override
	protected void dockingPositionChanged(String name,
		String oldPosition, String newPosition) {
		// TODO
	}

	@Override
	public void closeCurrentArea() {
		// TODO
	}

	@Override
	public JComponent floatDockableWindow(String name) {
		return getDockable(name) ;
	}

	@Override
	public DockingLayout getDockingLayout(ViewConfig config) {
		return _layout;
	}

	@Override
	public void hideDockableWindow(String name){
		// TODO: _widgets.get( name ) ;
	}
	
	@Override
	public boolean isDockableWindowDocked(String name){
		// TODO
		return (true);
	}

	@Override
	public boolean isDockableWindowVisible(String name){
		return true ;
		// return _widgets.get(name).isVisible( ) ;
	}

	@Override
	public void applyDockingLayout(DockingLayout docking){
		super.applyDockingLayout(null);
	}
	
	@Override
	public void showDockableWindow(String name){
		if(!_widgets.containsKey(name) ) {
			QDockWidget widget = createWidget( name ) ;
		} focusDockable( name ) ;
	}                     
	
	@Override
	protected void focusDockable(String name){
		Component window = _components.get(name) ;
		if( window == null ) return ;
		if (window instanceof DefaultFocusComponent)
			((DefaultFocusComponent)window).focusOnDefaultComponent();
		else
			window.requestFocus();
	}
	
	private QDockWidget createWidget( String name ){
		JComponent window = getDockable(name);
		if (window == null)
			window = createDockable(name);
		if (window == null)
			return null ;
		String title = getDockableTitle(name);
		
		QDockWidget widget = new QDockWidget( new QComponentHost( window ) );    
		widget.moveToThread( jEdit.getWindow().getThread() ) ;
		_widgets.put( name, widget ) ;  
		return widget ;
	}

	@Override
	public void setMainPanel(JPanel panel){
		add(panel, BorderLayout.CENTER);
	}

	public class JambiDockingDockingArea implements DockingArea {
		public void showMostRecent() {	}
		public String getCurrent() {
			return null ;
		}
		public void show(String name) { }
	}
	
	public DockingArea getBottomDockingArea() {
		return new JambiDockingDockingArea();
	}

	public DockingArea getLeftDockingArea() {
		return new JambiDockingDockingArea();
	}

	public DockingArea getRightDockingArea() {
		return new JambiDockingDockingArea();
	}

	public DockingArea getTopDockingArea() {
		return new JambiDockingDockingArea();
	}

	@Override
	protected void propertiesChanged() {
		super.propertiesChanged();
	}
	
	@Override
	public void dockableTitleChanged(String dockable, String newTitle) {
		
	}

	@Override
	protected void applyAlternateLayout(boolean alternateLayout) {
		
	}

	public void disposeDockableWindow(String name) {
		if( _widgets.containsKey( name ) ){
			// _widgets.get( name ).close( ) ;
		}
	}

	
}

