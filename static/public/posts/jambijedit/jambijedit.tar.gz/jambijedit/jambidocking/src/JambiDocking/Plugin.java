package JambiDocking ;

import org.gjt.sp.jedit.* ;
import org.gjt.sp.jedit.msg.*;
import org.gjt.sp.jedit.gui.*;
import org.gjt.sp.util.Log ;

import javax.swing.* ;
import java.awt.* ;

public class Plugin extends EBPlugin {
	public static final String NAME = "JambiDocking";
	
	public void start() { }
	public void stop() { }
	
	public void handleMessage(EBMessage message){} 
	
}

