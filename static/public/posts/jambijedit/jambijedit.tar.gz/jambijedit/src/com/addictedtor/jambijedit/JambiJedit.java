package com.addictedtor.jambijedit ;

import com.trolltech.qt.gui.*;
import com.trolltech.research.qtjambiawtbridge.QComponentHost;

import javax.swing.*;
import java.awt.*;

import org.gjt.sp.jedit.jEdit ;
import org.gjt.sp.jedit.View ;

public class JambiJedit extends QMainWindow {

		private JPanel panel ;
		private View view ;
		private Thread _thread ;
	
    public JambiJedit() {
        super( ) ;
				this.panel = new JPanel( new BorderLayout( ) ) ;
				startJedit( ) ;
				_thread = thread() ;
		}
		
		public JPanel getPanel(){
			return panel ;
		}

		public void startJedit( ){
				System.setProperty("jedit.home", "/opt/jedit"  ) ;
       
				jEdit.main( new String[] { 
					"-noserver", 
					"-settings=/home/romain/.jedit"
				} ,	this ) ;
				
				setCentralWidget( new QComponentHost( panel ) ) ;
		}
		
		public void setView( View view){
			this.view = view ;
		}
		
    public static void main(String[] args) {
        QApplication.initialize(args);
        JambiJedit jj = new JambiJedit();
        jj.showMaximized();
        QApplication.exec();
        System.exit(0);
    }
		
		public Thread getThread( ){
			return _thread ;
		}

}

